﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automato02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string stringEntrada = textBox1.Text;

         

            stringEntrada = "" + stringEntrada + " ";

            listboxlog.Items.Clear();

            listboxlog.Items.Add("*** Fita = " + stringEntrada);

            textBox1.Text = "";

            textBox2.Text = stringEntrada;

            MaquinaDeTuring automato = new MaquinaDeTuring();

            bool resultado = automato.Reconhecer(stringEntrada, listboxlog, textBox3);

            if (resultado == true)
            {
                labelResposta.Text = "Palíndromo";

            }
            else
            {
                labelResposta.Text = "Não é Palíndromo";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
