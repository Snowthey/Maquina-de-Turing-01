﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automato02
{


    internal class MaquinaDeTuring
    {
        private Dictionary<string, Estado> TabelaDeTransicao;


        public MaquinaDeTuring()
        {
            TabelaDeTransicao = new Dictionary<string, Estado>();

            Estado objetoEstadoq0 = new Estado(false);
            objetoEstadoq0.AdicionarTransicao('0', "q3","0", "D");
            objetoEstadoq0.AdicionarTransicao('1', "q1","1", "D");
            objetoEstadoq0.AdicionarTransicao('2', "q2","2", "D");
            objetoEstadoq0.AdicionarTransicao('3', "q4","3", "D");
            TabelaDeTransicao.Add("q0", objetoEstadoq0);

            Estado objetoEstadoq1 = new Estado(false);
            objetoEstadoq1.AdicionarTransicao('3', "q7","3", "D");
            objetoEstadoq1.AdicionarTransicao('2', "q6","2", "D");
            objetoEstadoq1.AdicionarTransicao('0', "q5","0", "D");
            objetoEstadoq1.AdicionarTransicao('1', "q1","1", "D");
            objetoEstadoq1.AdicionarTransicao(' ', "q42"," ", "D");
            TabelaDeTransicao.Add("q1", objetoEstadoq1);

            Estado objetoEstadoq2 = new Estado(false);
            objetoEstadoq2.AdicionarTransicao('0', "q33","0", "D");
            objetoEstadoq2.AdicionarTransicao('1', "q34","1", "D");
            objetoEstadoq2.AdicionarTransicao('3', "q32","3", "D");
            objetoEstadoq2.AdicionarTransicao('2', "q2", "2", "D");
            objetoEstadoq2.AdicionarTransicao(' ', "q42", " ", "D"); 
            TabelaDeTransicao.Add("q2", objetoEstadoq2);

            Estado objetoEstadoq3 = new Estado(false);
            objetoEstadoq3.AdicionarTransicao('1', "q24","1", "D");
            objetoEstadoq3.AdicionarTransicao('2', "q25","2", "D");
            objetoEstadoq3.AdicionarTransicao('3', "q23","3", "D");
            objetoEstadoq3.AdicionarTransicao('0', "q3", "0", "D");
            objetoEstadoq3.AdicionarTransicao(' ', "q42", " ", "D");
            TabelaDeTransicao.Add("q3", objetoEstadoq3);

            Estado objetoEstadoq4 = new Estado(false);
            objetoEstadoq4.AdicionarTransicao('0', "q20", "0", "D");
            objetoEstadoq4.AdicionarTransicao('1', "q27", "1", "D");
            objetoEstadoq4.AdicionarTransicao('2', "q14", "2", "D");
            objetoEstadoq4.AdicionarTransicao('3', "q4", "3", "D");
            objetoEstadoq4.AdicionarTransicao(' ', "q42", " ", "D");
            TabelaDeTransicao.Add("q4", objetoEstadoq4);

            Estado objetoEstadoq5 = new Estado(false);
            objetoEstadoq5.AdicionarTransicao('3', "q13", "3", "D");
            objetoEstadoq5.AdicionarTransicao('2', "q12", "2", "D");
            objetoEstadoq5.AdicionarTransicao('0', "q1", "0", "D");
            objetoEstadoq5.AdicionarTransicao('1', "q1", "1", "D");
            TabelaDeTransicao.Add("q5", objetoEstadoq5);

            Estado objetoEstadoq6 = new Estado(false);
            objetoEstadoq6.AdicionarTransicao('0', "q11", "0", "D");
            objetoEstadoq6.AdicionarTransicao('3', "q10", "3", "D");
            objetoEstadoq6.AdicionarTransicao('1', "q1", "1", "D");
            objetoEstadoq6.AdicionarTransicao('2', "q1", "2", "D");
            TabelaDeTransicao.Add("q6", objetoEstadoq6);

            Estado objetoEstadoq7 = new Estado(false);
            objetoEstadoq7.AdicionarTransicao('0', "q8", "0", "D");
            objetoEstadoq7.AdicionarTransicao('2', "q9", "2", "D");
            TabelaDeTransicao.Add("q7", objetoEstadoq7);

            Estado objetoEstadoq8 = new Estado(false);
            objetoEstadoq8.AdicionarTransicao('0', "q7", "0", "D");
            objetoEstadoq8.AdicionarTransicao('3', "q1", "3", "D");
            objetoEstadoq8.AdicionarTransicao('2', "q47", "2", "D");
            TabelaDeTransicao.Add("q8", objetoEstadoq8);

            Estado objetoEstadoq9 = new Estado(false);
            objetoEstadoq9.AdicionarTransicao('3', "q1", "3", "D");
            objetoEstadoq9.AdicionarTransicao('2', "q7", "2", "D");
            objetoEstadoq9.AdicionarTransicao('0', "q48", "0", "D");
            TabelaDeTransicao.Add("q9", objetoEstadoq9);

            Estado objetoEstadoq10 = new Estado(false);
            objetoEstadoq10.AdicionarTransicao('2', "q1", "2", "D");
            objetoEstadoq10.AdicionarTransicao('3', "q6", "3", "D");
            objetoEstadoq10.AdicionarTransicao('0', "q43", "0", "D");
            TabelaDeTransicao.Add("q10", objetoEstadoq10);

            Estado objetoEstadoq11 = new Estado(false);
            objetoEstadoq11.AdicionarTransicao('0', "q6", "0", "D");
            objetoEstadoq11.AdicionarTransicao('2', "q1", "2", "D");
            objetoEstadoq11.AdicionarTransicao('3', "q44", "3", "D");
            TabelaDeTransicao.Add("q11", objetoEstadoq11);

            Estado objetoEstadoq12 = new Estado(false);
            objetoEstadoq12.AdicionarTransicao('0', "q1", "0", "D");
            objetoEstadoq12.AdicionarTransicao('2', "q5", "2", "D");
            objetoEstadoq12.AdicionarTransicao('3', "q45", "3", "D");
            TabelaDeTransicao.Add("q12", objetoEstadoq12);

            Estado objetoEstadoq13 = new Estado(false);
            objetoEstadoq13.AdicionarTransicao('0', "q1", "0", "D");
            objetoEstadoq13.AdicionarTransicao('3', "q5", "3", "D");
            objetoEstadoq13.AdicionarTransicao('2', "q46", "2", "D");
            TabelaDeTransicao.Add("q13", objetoEstadoq13);

            Estado objetoEstadoq14 = new Estado(false);
            objetoEstadoq14.AdicionarTransicao('0', "q16", "0", "D");
            objetoEstadoq14.AdicionarTransicao('1', "q15", "1", "D");
            objetoEstadoq14.AdicionarTransicao('3', "q4", "3", "D");
            objetoEstadoq14.AdicionarTransicao('2', "q4", "2", "D");
            TabelaDeTransicao.Add("q14", objetoEstadoq14);

            Estado objetoEstadoq15 = new Estado(false);
            objetoEstadoq15.AdicionarTransicao('1', "q14", "1", "D");
            objetoEstadoq15.AdicionarTransicao('2', "q4", "2", "D");
            objetoEstadoq15.AdicionarTransicao('0', "q58", "0", "D");
            TabelaDeTransicao.Add("q15", objetoEstadoq15);

            Estado objetoEstadoq16 = new Estado(false);
            objetoEstadoq16.AdicionarTransicao('0', "q14", "0", "D");
            objetoEstadoq16.AdicionarTransicao('2', "q4", "2", "D");
            objetoEstadoq16.AdicionarTransicao('1', "q57", "1", "D");
            TabelaDeTransicao.Add("q16", objetoEstadoq16);

            Estado objetoEstadoq17 = new Estado(false);
            objetoEstadoq17.AdicionarTransicao('1', "q4", "1", "D");
            objetoEstadoq17.AdicionarTransicao('3', "q4", "3", "D");
            objetoEstadoq17.AdicionarTransicao('0', "q19", "0", "D");
            objetoEstadoq17.AdicionarTransicao('2', "q18", "2", "D");
            TabelaDeTransicao.Add("q17", objetoEstadoq17);

            Estado objetoEstadoq18 = new Estado(false);
            objetoEstadoq18.AdicionarTransicao('1', "q4", "1", "D");
            objetoEstadoq18.AdicionarTransicao('2', "q17", "2", "D");
            objetoEstadoq18.AdicionarTransicao('0', "q60", "0", "D");
            TabelaDeTransicao.Add("q18", objetoEstadoq18);

            Estado objetoEstadoq19 = new Estado(false);
            objetoEstadoq19.AdicionarTransicao('0', "q17", "0", "D");
            objetoEstadoq19.AdicionarTransicao('1', "q4", "1", "D");
            objetoEstadoq19.AdicionarTransicao('2', "q59", "2", "D");
            TabelaDeTransicao.Add("q19", objetoEstadoq19);

            Estado objetoEstadoq20 = new Estado(false);
            objetoEstadoq20.AdicionarTransicao('0', "q4", "0", "D");
            objetoEstadoq20.AdicionarTransicao('3', "q4", "3", "D");
            objetoEstadoq20.AdicionarTransicao('1', "q21", "1", "D");
            objetoEstadoq20.AdicionarTransicao('2', "q22", "2", "D");
            TabelaDeTransicao.Add("q20", objetoEstadoq20);

            Estado objetoEstadoq21 = new Estado(false);
            objetoEstadoq21.AdicionarTransicao('0', "q4", "0", "D");
            objetoEstadoq21.AdicionarTransicao('1', "q20", "1", "D");
            objetoEstadoq21.AdicionarTransicao('2', "q56", "2", "D");
            TabelaDeTransicao.Add("q21", objetoEstadoq21);

            Estado objetoEstadoq22 = new Estado(false);
            objetoEstadoq22.AdicionarTransicao('0', "q4", "0", "D");
            objetoEstadoq22.AdicionarTransicao('2', "q20", "2", "D");
            objetoEstadoq22.AdicionarTransicao('1', "q55", "1", "D");
            TabelaDeTransicao.Add("q22", objetoEstadoq22);

            Estado objetoEstadoq23 = new Estado(false);
            objetoEstadoq23.AdicionarTransicao('0', "q3", "0", "D");
            objetoEstadoq23.AdicionarTransicao('3', "q3", "3", "D");
            objetoEstadoq23.AdicionarTransicao('1', "q31", "1", "D");
            objetoEstadoq23.AdicionarTransicao('2', "q30", "2", "D");
            TabelaDeTransicao.Add("q23", objetoEstadoq23);

            Estado objetoEstadoq24 = new Estado(false);
            objetoEstadoq24.AdicionarTransicao('0', "q3", "0", "D");
            objetoEstadoq24.AdicionarTransicao('1', "q3", "1", "D");
            objetoEstadoq24.AdicionarTransicao('3', "q27", "3", "D");
            objetoEstadoq24.AdicionarTransicao('2', "q26", "2", "D");
            TabelaDeTransicao.Add("q24", objetoEstadoq24);

            Estado objetoEstadoq25 = new Estado(false);
            objetoEstadoq25.AdicionarTransicao('0', "q3", "0", "D");
            objetoEstadoq25.AdicionarTransicao('1', "q29", "1", "D");
            objetoEstadoq25.AdicionarTransicao('3', "q28", "3", "D");
            objetoEstadoq25.AdicionarTransicao('2', "q3", "2", "D");
            TabelaDeTransicao.Add("q25", objetoEstadoq25);

            Estado objetoEstadoq26 = new Estado(false);
            objetoEstadoq26.AdicionarTransicao('1', "q3", "1", "D");
            objetoEstadoq26.AdicionarTransicao('2', "q24", "2", "D");
            objetoEstadoq26.AdicionarTransicao('3', "q49", "3", "D");
            TabelaDeTransicao.Add("q26", objetoEstadoq26);

            Estado objetoEstadoq27 = new Estado(false);
            objetoEstadoq27.AdicionarTransicao('1', "q3", "1", "D");
            objetoEstadoq27.AdicionarTransicao('3', "q24", "3", "D");
            objetoEstadoq27.AdicionarTransicao('2', "q50", "2", "D");
            TabelaDeTransicao.Add("q27", objetoEstadoq27);

            Estado objetoEstadoq28 = new Estado(false);
            objetoEstadoq28.AdicionarTransicao('3', "q25", "3", "D");
            objetoEstadoq28.AdicionarTransicao('2', "q3", "2", "D");
            objetoEstadoq28.AdicionarTransicao('1', "q51", "1", "D");
            TabelaDeTransicao.Add("q28", objetoEstadoq28);

            Estado objetoEstadoq29 = new Estado(false);
            objetoEstadoq29.AdicionarTransicao('1', "q25", "1", "D");
            objetoEstadoq29.AdicionarTransicao('2', "q3", "2", "D");
            objetoEstadoq29.AdicionarTransicao('3', "q52", "3", "D");
            TabelaDeTransicao.Add("q29", objetoEstadoq29);

            Estado objetoEstadoq30 = new Estado(false);
            objetoEstadoq30.AdicionarTransicao('3', "q3", "3", "D");
            objetoEstadoq30.AdicionarTransicao('2', "q23", "2", "D");
            objetoEstadoq30.AdicionarTransicao('1', "q53", "1", "D");
            TabelaDeTransicao.Add("q30", objetoEstadoq30);

            Estado objetoEstadoq31 = new Estado(false);
            objetoEstadoq31.AdicionarTransicao('1', "q23", "1", "D");
            objetoEstadoq31.AdicionarTransicao('3', "q3", "3", "D");
            objetoEstadoq31.AdicionarTransicao('2', "q54", "2", "D");
            TabelaDeTransicao.Add("q31", objetoEstadoq31);

            Estado objetoEstadoq32 = new Estado(false);
            objetoEstadoq32.AdicionarTransicao('0', "q38", "0", "D");
            objetoEstadoq32.AdicionarTransicao('1', "q37", "1", "D");
            objetoEstadoq32.AdicionarTransicao('2', "q2", "2", "D");
            objetoEstadoq32.AdicionarTransicao('3', "q2", "3", "D");
            TabelaDeTransicao.Add("q32", objetoEstadoq32);

            Estado objetoEstadoq33 = new Estado(false);
            objetoEstadoq33.AdicionarTransicao('0', "q2", "0", "D");
            objetoEstadoq33.AdicionarTransicao('1', "q40", "1", "D");
            objetoEstadoq33.AdicionarTransicao('2', "q2", "2", "D");
            objetoEstadoq33.AdicionarTransicao('3', "q39", "3", "D");
            TabelaDeTransicao.Add("q33", objetoEstadoq33);

            Estado objetoEstadoq34 = new Estado(false);
            objetoEstadoq34.AdicionarTransicao('0', "q36", "0", "D");
            objetoEstadoq34.AdicionarTransicao('1', "q2", "1", "D");
            objetoEstadoq34.AdicionarTransicao('2', "q2", "2", "D");
            objetoEstadoq34.AdicionarTransicao('3', "q35", "3", "D");
            TabelaDeTransicao.Add("q34", objetoEstadoq34);

            Estado objetoEstadoq35 = new Estado(false);
            objetoEstadoq35.AdicionarTransicao('3', "q34", "3", "D");
            objetoEstadoq35.AdicionarTransicao('1', "q2", "1", "D");
            objetoEstadoq35.AdicionarTransicao('0', "q63", "0", "D");
            TabelaDeTransicao.Add("q35", objetoEstadoq35);

            Estado objetoEstadoq36 = new Estado(false);
            objetoEstadoq36.AdicionarTransicao('0', "q34", "0", "D");
            objetoEstadoq36.AdicionarTransicao('1', "q2", "1", "D");
            objetoEstadoq36.AdicionarTransicao('3', "q64", "3", "D");
            TabelaDeTransicao.Add("q36", objetoEstadoq36);

            Estado objetoEstadoq37 = new Estado(false);
            objetoEstadoq37.AdicionarTransicao('3', "q2", "3", "D");
            objetoEstadoq37.AdicionarTransicao('1', "q32", "1", "D");
            objetoEstadoq37.AdicionarTransicao('0', "q61", "0", "D");
            TabelaDeTransicao.Add("q37", objetoEstadoq37);

            Estado objetoEstadoq38 = new Estado(false);
            objetoEstadoq38.AdicionarTransicao('3', "q2", "3", "D");
            objetoEstadoq38.AdicionarTransicao('0', "q32", "0", "D"); 
            objetoEstadoq38.AdicionarTransicao('1', "q62", "1", "D");
            TabelaDeTransicao.Add("q38", objetoEstadoq38);

            Estado objetoEstadoq39 = new Estado(false);
            objetoEstadoq39.AdicionarTransicao('3', "q33", "3", "D");
            objetoEstadoq39.AdicionarTransicao('0', "q2", "0", "D");
            objetoEstadoq39.AdicionarTransicao('1', "q65", "1", "D");
            TabelaDeTransicao.Add("q39", objetoEstadoq39);

            Estado objetoEstadoq40 = new Estado(false);
            objetoEstadoq40.AdicionarTransicao('1', "q33", "1", "D");
            objetoEstadoq40.AdicionarTransicao('0', "q2", "0", "D");
            objetoEstadoq40.AdicionarTransicao('3', "q66", "3", "D");
            TabelaDeTransicao.Add("q40", objetoEstadoq40);

            Estado objetoEstadoq41 = new Estado(true);
            TabelaDeTransicao.Add("q41", objetoEstadoq41);

            Estado objetoEstadoq42 = new Estado(true);
            TabelaDeTransicao.Add("q42", objetoEstadoq42);

            Estado objetoEstadoq43 = new Estado(false);
            objetoEstadoq43.AdicionarTransicao('3', "q10", "3", "D");
            TabelaDeTransicao.Add("q43", objetoEstadoq43);

            Estado objetoEstadoq44 = new Estado(false);
            objetoEstadoq44.AdicionarTransicao('0', "q11", "0", "D");
            TabelaDeTransicao.Add("q44", objetoEstadoq44);

            Estado objetoEstadoq45 = new Estado(false);
            objetoEstadoq45.AdicionarTransicao('2', "q12", "2", "D");
            TabelaDeTransicao.Add("q45", objetoEstadoq45);

            Estado objetoEstadoq46 = new Estado(false);
            objetoEstadoq46.AdicionarTransicao('3', "q13", "3", "D");
            TabelaDeTransicao.Add("q46", objetoEstadoq46);

            Estado objetoEstadoq47 = new Estado(false);
            objetoEstadoq47.AdicionarTransicao('0', "q8", "0", "D");
            TabelaDeTransicao.Add("q47", objetoEstadoq47);

            Estado objetoEstadoq48 = new Estado(false);
            objetoEstadoq48.AdicionarTransicao('2', "q9", "2", "D");
            TabelaDeTransicao.Add("q48", objetoEstadoq48);

            Estado objetoEstadoq49 = new Estado(false);
            objetoEstadoq49.AdicionarTransicao('2', "q26", "2", "D");
            TabelaDeTransicao.Add("q49", objetoEstadoq49);

            Estado objetoEstadoq50 = new Estado(false);
            objetoEstadoq50.AdicionarTransicao('3', "q27", "3", "D");
            TabelaDeTransicao.Add("q50", objetoEstadoq50);

            Estado objetoEstadoq51 = new Estado(false);
            objetoEstadoq51.AdicionarTransicao('3', "q28", "3", "D");
            TabelaDeTransicao.Add("q51", objetoEstadoq51);

            Estado objetoEstadoq52 = new Estado(false);
            objetoEstadoq52.AdicionarTransicao('1', "q29", "1", "D");
            TabelaDeTransicao.Add("q52", objetoEstadoq52);

            Estado objetoEstadoq53 = new Estado(false);
            objetoEstadoq53.AdicionarTransicao('2', "q30", "2", "D");
            TabelaDeTransicao.Add("q53", objetoEstadoq53);

            Estado objetoEstadoq54 = new Estado(false);
            objetoEstadoq54.AdicionarTransicao('1', "q31", "1", "D");
            TabelaDeTransicao.Add("q54", objetoEstadoq54);

            Estado objetoEstadoq55 = new Estado(false);
            objetoEstadoq55.AdicionarTransicao('2', "q22", "2", "D");
            TabelaDeTransicao.Add("q55", objetoEstadoq55);

            Estado objetoEstadoq56 = new Estado(false);
            objetoEstadoq56.AdicionarTransicao('1', "q21", "1", "D");
            TabelaDeTransicao.Add("q56", objetoEstadoq56);

            Estado objetoEstadoq57 = new Estado(false);
            objetoEstadoq57.AdicionarTransicao('0', "q16", "0", "D");
            TabelaDeTransicao.Add("q57", objetoEstadoq57);

            Estado objetoEstadoq58 = new Estado(false);
            objetoEstadoq58.AdicionarTransicao('1', "q15", "1", "D");
            TabelaDeTransicao.Add("q58", objetoEstadoq58);

            Estado objetoEstadoq59 = new Estado(false);
            objetoEstadoq59.AdicionarTransicao('0', "q19", "0", "D");
            TabelaDeTransicao.Add("q59", objetoEstadoq59);

            Estado objetoEstadoq60 = new Estado(false);
            objetoEstadoq60.AdicionarTransicao('2', "q18", "2", "D");
            TabelaDeTransicao.Add("q60", objetoEstadoq60);

            Estado objetoEstadoq61 = new Estado(false);
            objetoEstadoq61.AdicionarTransicao('1', "q37", "1", "D");
            TabelaDeTransicao.Add("q61", objetoEstadoq61);

            Estado objetoEstadoq62 = new Estado(false);
            objetoEstadoq62.AdicionarTransicao('0', "q38", "0", "D");
            TabelaDeTransicao.Add("q62", objetoEstadoq62);

            Estado objetoEstadoq63 = new Estado(false);
            objetoEstadoq63.AdicionarTransicao('3', "q35", "3", "D");
            TabelaDeTransicao.Add("q63", objetoEstadoq63);

            Estado objetoEstadoq64 = new Estado(false);
            objetoEstadoq64.AdicionarTransicao('0', "q36", "0", "D");
            TabelaDeTransicao.Add("q64", objetoEstadoq64);

            Estado objetoEstadoq65 = new Estado(false);
            objetoEstadoq65.AdicionarTransicao('3', "q39", "3", "D");
            TabelaDeTransicao.Add("q65", objetoEstadoq65);

            Estado objetoEstadoq66 = new Estado(false);
            objetoEstadoq66.AdicionarTransicao('1', "q40", "1", "D");
            TabelaDeTransicao.Add("q66", objetoEstadoq66);
        }

        public bool Reconhecer(String palavra, ListBox log, TextBox textBoxFita)
        {
            string EstadoAtual = "q0";

            int TamanhoPalavra = palavra.Length;

            char[] charFita = palavra.ToCharArray();

            int indiceFita = 0;
            bool MaquinadeTuringParou = false;
            MovimentoTuring objetoTransicaoTuring;
            string EscreverNaFita = "";
            string MovimentoCabecote = "";
            int contador = 0;

            while((MaquinadeTuringParou == false) || (contador < 10000))
            {
                string textolog;
                textolog = "Estado atual = " + EstadoAtual + "-- Simbolo lido = " + charFita.ElementAtOrDefault(indiceFita);

                objetoTransicaoTuring = TabelaDeTransicao[EstadoAtual].RetornarMovimentoTuring(charFita.ElementAtOrDefault(indiceFita));

                if (objetoTransicaoTuring == null)
                {
                    textolog += "--> NÃO VAI PARA NENHUM ESTADO";
                    log.Items.Add(textolog);
                    return false;
                }
                else
                {
                    textolog += "--> va para estado: " + EstadoAtual + " Escrever: " + EscreverNaFita + "Movimento Cabeçote: " + MovimentoCabecote;
                    log.Items.Add(textolog);

                    EstadoAtual = objetoTransicaoTuring.ProximoEstado;
                    EscreverNaFita = objetoTransicaoTuring.EscreverNaFita;
                    MovimentoCabecote = objetoTransicaoTuring.Movimento;

                    charFita[indiceFita] = EscreverNaFita[0];

                    string strFita = new string(charFita);
                    textBoxFita.Text = strFita;

                    if((indiceFita == 0) && (EscreverNaFita == "E"))
                    {
                        textolog += "--> Movimento Inválido! Máqina parou no inicio da fita.";
                        log.Items.Add(textolog);
                        return false;
                    }
                    if (MovimentoCabecote == "E")
                    {
                        indiceFita = indiceFita - 1;
                    }
                    else if (MovimentoCabecote == "D")
                    {
                        indiceFita = indiceFita + 1;
                    }
                }

                Debug.WriteLine("Estado atual: " + EstadoAtual);


                if (TabelaDeTransicao[EstadoAtual].EhEstadoFinal())
                {
                    log.Items.Add("ESTADO FINAL");
                    return true;
                }
            }

            if (contador >= 10000)
            {
                return false;
            }
            else return true;
        }

    }
}
