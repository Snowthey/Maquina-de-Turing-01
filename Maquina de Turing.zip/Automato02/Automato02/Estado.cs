﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Automato02
{
    internal class Estado
    {
        private bool EstadoFinal;

        Dictionary<char, MovimentoTuring> Transicoes;

        public Estado(bool tipoEstado)
        {
            this.EstadoFinal = tipoEstado;

            Transicoes = new Dictionary<char, MovimentoTuring>();
        }

        public bool EhEstadoFinal()
        {
            return EstadoFinal;
        }

        public void AdicionarTransicao(char SimboloLido, string proximo, string escrita, string mover)
        {
            MovimentoTuring objetoMovimentoTuring = new MovimentoTuring(proximo, escrita, mover);
            Transicoes.Add(SimboloLido , objetoMovimentoTuring);
        }

        public MovimentoTuring RetornarMovimentoTuring(char SimboloLido)
        {
            if (Transicoes.ContainsKey(SimboloLido))
            {
                return Transicoes[SimboloLido];
            }
            else
            {
                return null;
            }
        }

    }
}
