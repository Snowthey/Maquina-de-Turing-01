﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Automato02
{
    internal class MovimentoTuring
    {
        public string ProximoEstado;
        public string EscreverNaFita;
        public string Movimento;

        public MovimentoTuring(string proximo, string escrita, string mover)
        {
            ProximoEstado = proximo;
            EscreverNaFita = escrita;
            Movimento = mover;
        }
    }
}
